import asyncio
import aiohttp
import socket
from typing import List, Optional, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime
from Models.proxy import Proxy
import ssl
from log import logger
from fake_useragent import UserAgent
import urllib.parse
import socks
import socket


ua = UserAgent()

class ProxyValidator:
    def __init__(self, db: AsyncSession):
        """
        Инициализация с использованием асинхронной сессии
        
        :param db: Асинхронная сессия SQLAlchemy
        """
        self.db = db
        # Создаем SSL-контекст с отключенной проверкой
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE

    async def test_tcp_connection(self, proxy: Proxy, timeout: float = 5.0) -> bool:
        """Проверка TCP-соединения с прокси"""
        try:
            # Определяем тип прокси
            proxy_type = self.get_socks_type(proxy.type)
            
            # Настраиваем сокет
            sock = socks.socksocket()
            sock.set_proxy(
                proxy_type, 
                proxy.ip, 
                proxy.port, 
                username=proxy.username if proxy.username else None, 
                password=proxy.password if proxy.password else None
            )
            
            # Пытаемся подключиться к публичному DNS-серверу
            sock.connect(('8.8.8.8', 53))
            sock.close()
            
            logger.info(f"Прокси {proxy.ip}:{proxy.port} TCP - OK")
            return True
        except Exception as e:
            logger.warning(f"Прокси {proxy.ip}:{proxy.port} TCP - FAIL: {e}")
            return False

    def get_socks_type(self, proxy_type: str) -> int:
        """
        Преобразование строкового типа прокси в числовой тип socks
        """
        proxy_type = proxy_type.lower()
        if proxy_type == 'socks4':
            return socks.SOCKS4
        elif proxy_type == 'socks5':
            return socks.SOCKS5
        elif proxy_type in ['http', 'https']:
            return socks.HTTP
        else:
            # По умолчанию используем SOCKS5
            return socks.SOCKS5

    def prepare_proxy_url(self, proxy: Proxy) -> str:
        """
        Подготовка корректной прокси-ссылки
        """
        # Нормализуем тип прокси к нижнему регистру
        proxy_type = proxy.type.lower()
        
        # Проверяем корректность типа прокси
        if proxy_type not in ['http', 'https', 'socks4', 'socks5']:
            proxy_type = 'socks5'  # По умолчанию используем socks5
        
        # Формируем URL с кодированием специальных символов
        if proxy.username and proxy.password:
            # Кодируем имя пользователя и пароль
            username = urllib.parse.quote(proxy.username)
            password = urllib.parse.quote(proxy.password)
            proxy_url = f"{proxy_type}://{username}:{password}@{proxy.ip}:{proxy.port}"
        else:
            proxy_url = f"{proxy_type}://{proxy.ip}:{proxy.port}"
        
        return proxy_url

    async def test_http_connection(self, proxy: Proxy, url: str, timeout: float = 10.0) -> bool:
        """Расширенная проверка HTTP(S) соединения через прокси"""
        try:
            # Подготавливаем прокси-URL
            proxy_url = self.prepare_proxy_url(proxy)

            # Создаем коннектор с отключенной проверкой SSL
            connector = aiohttp.TCPConnector(
                ssl=False  # Полностью отключаем SSL
            )

            async with aiohttp.ClientSession(connector=connector) as session:
                try:
                    async with session.get(
                        url, 
                        proxy=proxy_url, 
                        timeout=aiohttp.ClientTimeout(total=timeout),
                        headers={
                            'User-Agent': ua.random,
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.5',
                            'Connection': 'keep-alive',
                        }
                    ) as response:
                        # Расширенная проверка ответа
                        if response.status in [200, 204, 206, 301, 302, 303, 307, 308]:
                            try:
                                # Читаем только первые 1000 символов
                                content = await response.text(encoding='utf-8', errors='ignore')[:1000]
                                result = len(content) > 10
                                logger.info(f"Прокси {proxy.ip}:{proxy.port} для URL {url}: {'OK' if result else 'FAIL'}")
                                return result
                            except Exception as e:
                                logger.warning(f"Proxy {proxy.ip}:{proxy.port} ошибка чтения контента: {e}")
                                return True
                        
                        logger.warning(f"Proxy {proxy.ip}:{proxy.port} вернул статус {response.status}")
                        return False
                except Exception as e:
                    logger.error(f"Proxy {proxy.ip}:{proxy.port} ошибка в запросе: {str(e)}")
                    return False

        except Exception as e:
            logger.error(f"Proxy {proxy.ip}:{proxy.port} неизвестная ошибка: {str(e)}")
            return False

    async def validate_proxy(self, proxy: Proxy) -> Dict[str, bool]:
        """Полная валидация прокси для разных платформ"""
        results = {
            'twitchValid': False,
            'youtubeValid': False,
            'kickValid': False
        }

        # Сначала проверяем TCP-соединение
        tcp_valid = await self.test_tcp_connection(proxy)
        if not tcp_valid:
            logger.info(f"Proxy {proxy.ip}:{proxy.port} не прошел TCP-тест")
            return results

        # Тесты для разных платформ
        platforms = [
            ('twitchValid', 'https://www.twitch.tv/'),
            ('youtubeValid', 'https://www.youtube.com/'),
            ('kickValid', 'https://kick.com/')
        ]

        for platform_key, url in platforms:
            try:
                results[platform_key] = await self.test_http_connection(proxy, url)
                logger.info(f"Прокси {proxy.ip}:{proxy.port} для {platform_key}: {results[platform_key]}")
            except Exception as e:
                logger.error(f"Ошибка валидации для {url}: {e}")
                results[platform_key] = False

        return results

    async def validate_proxies(self, proxies: List[Proxy], max_concurrent: int = 10):
        """
        Асинхронная валидация списка прокси с ограничением конкурентных задач
        """
        # Создаем семафор для ограничения количества одновременных задач
        semaphore = asyncio.Semaphore(max_concurrent)

        async def validate_with_semaphore(proxy):
            async with semaphore:
                try:
                    logger.info(f"Proxy details: type={proxy.type}, ip={proxy.ip}, port={proxy.port}, "
                    f"username={proxy.username}, password={'*' * len(proxy.password) if proxy.password else None}")
                    # Выполняем валидацию
                    validation_results = await self.validate_proxy(proxy)
                    
                    # Обновляем прокси
                    proxy.twitchValid = validation_results['twitchValid']
                    proxy.youtubeValid = validation_results['youtubeValid']
                    proxy.kickValid = validation_results['kickValid']
                    proxy.lastChecked = datetime.now()                    
                    return proxy
                except Exception as e:
                    logger.error(f"Ошибка при валидации прокси {proxy.ip}:{proxy.port}: {e}")
                    return None

        # Создаем список задач для валидации
        validation_tasks = [validate_with_semaphore(proxy) for proxy in proxies]
        
        # Запускаем все задачи одновременно
        results = await asyncio.gather(*validation_tasks)
        
        # Фильтруем None результаты
        return [r for r in results if r is not None]

    async def validate_all_proxies(self, max_concurrent: int = 10):
        """
        Валидация всех прокси в базе данных
        """
        # Получаем все прокси
        result = await self.db.execute(select(Proxy))
        proxies = result.scalars().all()
        
        logger.info(f"Начало валидации {len(proxies)} прокси")
        
        # Запускаем валидацию
        validated_proxies = await self.validate_proxies(proxies, max_concurrent)
        
        # Коммитим изменения
        await self.db.commit()
        
        logger.info(f"Завершена валидация {len(validated_proxies)} прокси")
        
        return validated_proxies