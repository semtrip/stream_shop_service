import os
from typing import List
from Models.proxy import Proxy
from Data.Repositories.proxyRepository import ProxyRepository
import re
from datetime import datetime

class ProxyService:
    def __init__(self, db):
        self.db = db
        self.repo = ProxyRepository(db)

    def parse_proxy(self, line: str, proxy_type: str) -> Proxy:
        """Парсинг строки прокси с различными форматами"""
        # Очистка строки от пробелов
        line = line.strip()
        
        # Форматы:
        # 1. ip:port
        # 2. ip:port:username:password
        # 3. username:password@ip:port
        
        # Разбор username:password@ip:port
        at_match = re.match(r'^(.+?)@(.+):(\d+)$', line)
        if at_match:
            username, ip, port = at_match.groups()
            if ':' in username:
                username, password = username.split(':')
            else:
                password = None
            return Proxy(
                ip=ip, 
                port=int(port), 
                username=username, 
                password=password, 
                type=proxy_type, 
                twitchValid=False,
                youtubeValid=False,
                kickValid=False,
                lastChecked = datetime.now()
            )
        
        # Разбор ip:port:username:password
        parts = line.split(':')
        if len(parts) == 2:
            ip, port = parts
            username, password = None, None
        elif len(parts) == 4:
            ip, port, username, password = parts
        else:
            raise ValueError(f"Неверный формат прокси: {line}")
        
        return Proxy(
            ip=ip, 
            port=int(port), 
            username=username, 
            password=password, 
            type=proxy_type, 
            twitchValid=False,
            youtubeValid=False,
            kickValid=False,
            lastChecked = datetime.now()
        )

    async def load_from_file(self, path: str, proxy_type: str) -> int:
        """Загрузка прокси из файла с указанием типа"""
        if not os.path.exists(path):
            print(f"Файл не найден: {path}")
            return 0

        proxies: List[Proxy] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    proxy = self.parse_proxy(line, proxy_type)
                    proxies.append(proxy)
                except Exception as e:
                    print(f"Ошибка парсинга строки '{line}': {e}")
        
        return await self.repo.bulk_insert_proxies(proxies)