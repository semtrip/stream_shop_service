import os
from typing import List
from Models.account import Account
from Data.Repositories.accountRepository import AccountRepository

class AccountService:
    def __init__(self, db):
        self.db = db
        self.repo = AccountRepository(db)

    def parse_account(self, line: str, platform: str) -> Account:
        """Парсинг строки аккаунта с различными форматами"""
        # Очистка строки от пробелов
        line = line.strip()
        
        # Форматы:
        # 1. login:auth-token
        # 2. login auth-token
        
        # Проверяем, есть ли разделитель
        if ':' in line:
            parts = line.split(':', 1)
        else:
            parts = line.split(None, 1)
        
        if len(parts) != 2:
            raise ValueError(f"Неверный формат аккаунта: {line}")
        
        user, token = parts
        
        return Account(
            user=user,
            token=token,
            platform=platform,
            cookies="",  # Если нужны куки, их можно будет добавить позже
            isValid=False
        )

    async def load_from_file(self, path: str, platform: str) -> int:
        """Загрузка аккаунтов из файла с указанием платформы"""
        if not os.path.exists(path):
            print(f"Файл не найден: {path}")
            return 0

        accounts: List[Account] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    account = self.parse_account(line, platform)
                    accounts.append(account)
                except Exception as e:
                    print(f"Ошибка парсинга строки '{line}': {e}")
        
        await self.repo.add_accounts(accounts)
        return len(accounts)