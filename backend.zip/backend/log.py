from log_streamer import LogStreamer

log_streamer = LogStreamer()
logger = log_streamer.logger
